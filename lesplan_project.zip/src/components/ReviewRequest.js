import React, { useState } from 'react';

function ReviewRequest() {
  const [email, setEmail] = useState('');

  const handleSendRequest = () => {
    alert(`Review verzoek verzonden naar ${email}`);
  };

  return (
    <div>
      <h2>Reviewverzoek</h2>
      <label>
        Leerling Email:
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <br />
      <button onClick={handleSendRequest}>Verstuur Reviewverzoek</button>
    </div>
  );
}

export default ReviewRequest;
