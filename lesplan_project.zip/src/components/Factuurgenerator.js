import React, { useState } from 'react';

function Factuurgenerator() {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');

  const handleGenerate = () => {
    alert(`Factuur voor ${name} gegenereerd voor het bedrag van €${amount}`);
  };

  return (
    <div>
      <h2>Factuurgenerator</h2>
      <label>
        Naam:
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <br />
      <label>
        Bedrag:
        <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
      </label>
      <br />
      <button onClick={handleGenerate}>Genereer Factuur</button>
    </div>
  );
}

export default Factuurgenerator;
