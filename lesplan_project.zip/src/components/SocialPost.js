import React from 'react';

function SocialPost() {
  const handleGeneratePost = () => {
    alert("Social Media bericht is gegenereerd voor een geslaagde leerling!");
  };

  return (
    <div>
      <h2>Social Media Bericht</h2>
      <button onClick={handleGeneratePost}>Genereer Bericht</button>
    </div>
  );
}

export default SocialPost;
