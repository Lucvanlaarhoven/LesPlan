import React, { useState } from 'react';

function Lesplanning() {
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  const handlePlanLes = () => {
    alert(`Les gepland voor ${date} om ${time}`);
  };

  return (
    <div>
      <h2>Lesplanning</h2>
      <label>
        Datum:
        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </label>
      <br />
      <label>
        Tijd:
        <input type="time" value={time} onChange={(e) => setTime(e.target.value)} />
      </label>
      <br />
      <button onClick={handlePlanLes}>Plan Les</button>
    </div>
  );
}

export default Lesplanning;
